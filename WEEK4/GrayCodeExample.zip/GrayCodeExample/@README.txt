@README - the list of default project files
--------------------------------


*** Some examples for the lecture
MuxMHL2.vhd -- Morse beacon by multiplexer
testbench_muxmhl2.vhd -- its testbench

ToGray.vhd - binary code to binary reflacted gray
testbench_togray.bdf - its testbench

GrayCounter.vhd - the last example from lecture
testbench_graycounter.vhd - its testbench

*** simulation
rungray.bat - GHDL simulation of graycode
runmhl2.bat - GHDL simulation of MuxMHL2
runcounter.bat - GHDL simulation of all architectures of GrayCounter

runwave.bat  - common, it displays last simulation

*** Auxiliary
Off_VEEKMT2_LCD.vhd - switching off back LCD, if it is not used
Off_VEEKMT2_LCD.bsf - the generated symbol for the block diagram/schematic editor


*** Important definitions - always copy them to each Quartus project
VeekMT2.sdc - the definitions for TimeQuest Analyzer
VeekMT2_PinAssignments.csv - Pin Assignments of VeekMT2 board
